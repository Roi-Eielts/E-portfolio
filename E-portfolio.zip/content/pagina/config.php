<?php 
$servername = "localhost";
$username = "root";
$password = "MOZs15jS!";
?>
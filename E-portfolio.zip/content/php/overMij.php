<script src="content/javascript/overmij.js"></script>
<div class="container home_text">
    <div class="row">
        <div class="col-md-6">
            <h1>over mij</h1>
            <p>
                Hallo! Mijn naam is Roï Eielts, ben 17 jaar uit en ik ben geboren in Goes op 7 september 2004.
                Persoonlijk ben ik ben zelf erg geduldig, vrolijk, optimistisch, zelfstandig en ik ben altijd een
                persoon die doorzet als iets tegenzit. Daarnaast heb ik een bijbaantje als slagerij medewerker bij de
                jumbo foodcorner in Goes. Natuurlijk heb ik hobby`s met als mijn favoriete hobby auto`s spotten, maar ik
                vind het ook leuk om paarden te verzorgen en met de auto rijden. Verder doe ik ook nog een opleiding
                genaamd Software Development waarbij ik in leerjaar 1 zit. Ik heb deze opleiding gekozen om mijn kennis
                op computers te kunnen verbeteren en om te leren hoe je een applicatie te ontwikkelen.
            </p>
        </div>
        <div class="col-md-6">
            <p>Dit ben ik</p>
            <img src="content/img/roi.png" class="afbeelding">
        </div>
    </div>
</div>
<div class="ruimte">
    <h3 class="center">opleiding</h3>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <p>
                op dit moment krijg ik les in databases, programmeren, software engineering ontwerpen en projectmatig werken (SCRUM). Verder krijg ik ook de Algemeen Vormende vakken; Nederlands, Rekenen/Wiskunde, Engels en Burgerschap Vitale Dimensie (Gym). Verder krijg ik ook nog loopbaansturing.
            </p>
        </div>
        <div class="col-md-6">
            <div class="offcanvas offcanvas-bottom kleurtjes" id="sprint">
                <div class="offcanvas-header">
                    <p></p>
                    <button type="button" class="btn-close knop" data-bs-dismiss="offcanvas"></button>
                </div>
                <div class="offcanvas-body">
                    <!-- Tab links -->
                    <div class="tab">
                        <button class="tablinks" onclick="vak(event, '1')">sprint 1</button>
                        <button class="tablinks" onclick="vak(event, '2')">sprint 2</button>
                        <button class="tablinks" onclick="vak(event, '3')">sprint 3</button>
                        <button class="tablinks" onclick="vak(event, '4')">sprint 4</button>
                        <button class="tablinks" onclick="vak(event, '5')">sprint 5</button>
                        <button class="tablinks" onclick="vak(event, '6')">sprint 6</button>
                        <button class="tablinks" onclick="vak(event, '7')">sprint 7</button>
                        <button class="tablinks" onclick="vak(event, '8')">sprint 8</button>
                        <button class="tablinks" onclick="vak(event, '9')">sprint 9</button>
                    </div>

                    <!-- Tab content -->
                    <div id="1" class="tabcontent">
                        <table class="table-dark table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vak</th>
                                    <th>Kennis toets</th>
                                    <th>Review</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Programmeren</td>
                                    <td>5.4</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Databases</td>
                                    <td>6.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Front End Development</td>
                                    <td>8.8</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>scrum</td>
                                    <td>7.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Loopbaansturing</td>
                                    <td>7.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Software Engeneering</td>
                                    <td>6.0</td>
                                    <td>V</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div id="2" class="tabcontent">
                        <table class="table-dark table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vak</th>
                                    <th>Kennis toets</th>
                                    <th>Review</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Programmeren</td>
                                    <td>7.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Databases</td>
                                    <td>8.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Front End Development</td>
                                    <td>5.0</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>scrum</td>
                                    <td>6.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Loopbaansturing</td>
                                    <td>8.0</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>Software Engeneering</td>
                                    <td>7.0</td>
                                    <td>V</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div id="3" class="tabcontent">
                        <table class="table-dark table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vak</th>
                                    <th>Kennis toets</th>
                                    <th>Review</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Programmeren</td>
                                    <td>5.4</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Databases</td>
                                    <td>8.0</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>Front End Development</td>
                                    <td>7.5</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>scrum</td>
                                    <td>7.3</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Loopbaansturing</td>
                                    <td>8.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Software Engeneering</td>
                                    <td>5.0</td>
                                    <td>V</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="4" class="tabcontent">
                        <table class="table-dark table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vak</th>
                                    <th>Kennis toets</th>
                                    <th>Review</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Programmeren</td>
                                    <td>2</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Databases</td>
                                    <td>8.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Front End Development</td>
                                    <td>7</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>scrum</td>
                                    <td>8.0</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>Loopbaansturing</td>
                                    <td>6.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Software Engeneering</td>
                                    <td>7.0</td>
                                    <td>V</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="5" class="tabcontent">
                        <table class="table-dark table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vak</th>
                                    <th>Kennis toets</th>
                                    <th>Review</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Programmeren</td>
                                    <td>9</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Databases</td>
                                    <td>8.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Front End Development</td>
                                    <td>7</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>scrum</td>
                                    <td>8.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Loopbaansturing</td>
                                    <td>7.0</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Software Engeneering</td>
                                    <td>8.0</td>
                                    <td>V</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="6" class="tabcontent">
                        <table class="table-dark table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vak</th>
                                    <th>Kennis toets</th>
                                    <th>Review</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Programmeren</td>
                                    <td>6</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Databases</td>
                                    <td>7</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Front End Development</td>
                                    <td>10</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>scrum</td>
                                    <td>7</td>
                                    <td>G</td>
                                </tr>
                                <tr>
                                    <td>Loopbaansturing</td>
                                    <td>9</td>
                                    <td>V</td>
                                </tr>
                                <tr>
                                    <td>Software Engeneering</td>
                                    <td>7</td>
                                    <td>V</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div id="7" class="tabcontent">
                        <H1>binnenkort meer te zien hier</H1>
                    </div>
                    <div id="8" class="tabcontent">
                        <H1>binnenkort meer te zien hier</H1>
                    </div>
                    <div id="9" class="tabcontent">
                        <H1>binnenkort meer te zien hier</H1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#sprint">
                        Schoolvakken & cijfer per sprint.
                    </button>
                </div>
                <div class="col-md-6">
                </div>
            </div>
        </div>
    </div>
</div>